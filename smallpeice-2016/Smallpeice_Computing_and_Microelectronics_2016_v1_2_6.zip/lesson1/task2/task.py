from sr import *

R =# Start up (initialise) your robot here!